README for Visualization Badges Supplementary Material

Content Overview
================
1) design-inspirations-from-real-world/
   - Visual examples of how “badge-like” labels are used in various real-world contexts (e.g., product packaging, GitHub repos, etc.).

2)  magazine-articles-for-coding/
   - Contains the 80 magazine articles we coded

3) vis-badges-catalog/
   - Final spreadsheet listing the 132 visualizations badges including its source (literature, coding articles or co-design workshops)
   - Also available at: https://vis-badges.github.io
   - Also provided in the Appendix "visualization-badges-appendix.pdf" without its sources

4) visualization-badges-appendix.pdf
   - Appendix of the main paper

How to Navigate
===============
- To view the complete set of badges we point to "visualization-badges-appendix.pdf" (Appendix C) or "vis-badges-catalog/"
- If you are interested in the articles we used for coding, look into "magazine-articles-for-coding"
- If you are interested in the original sources of our badges (literature, magazine or co-design workshop) we point to "vis-badges-coded-catalog/"
- For visual examples of "badge-like" labels from various real-world context we point to "design-inspirations-from-real-world/"





